# Load required library
library(utils)

# Define zip file and extract location
zip_file <- "Employee_Profile.zip"
extract_folder <- "Employee Profile"

# Unzip the file
unzip(zip_file, exdir = extract_folder)

# Get the CSV file name inside the extracted folder
csv_file <- list.files(extract_folder, pattern = "\\.csv$", full.names = TRUE)[1]

# Read and display the CSV data
employee_data <- read.csv(csv_file)
print(employee_data)
