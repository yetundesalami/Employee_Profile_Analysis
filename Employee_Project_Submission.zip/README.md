# Employee Profile Analysis

## Overview
This project processes employee data using R and Python. It extracts and displays employee details from a compressed file.

## Files Included
- `Employee_Profile.zip`: The dataset file.
- `unzip_display.R`: The R script to unzip and display employee details.
- `README.md`: Instructions for running the code.

## How to Use
1. **Unzip the Employee_Profile.zip file** in your working directory.
2. **Run the R script** by executing:
   ```r
   source("unzip_display.R")
